import WeddingEventsEvents from "./components/wedding_serv";
function WeddingEvents(){
    return (
        <>
            <WeddingEventsEvents/>
        </>
    )
}
export default WeddingEvents;