import EventsEvents from "./components/event_serv";
function EventsSocial(){
    return (
        <>
            <EventsEvents/>
        </>
    )
}
export default EventsSocial;