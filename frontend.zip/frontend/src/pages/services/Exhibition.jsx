import ExhibitionEvents from "./components/exhibition_serv";

function ExhibitionSocial(){
    return (
        <>
            <ExhibitionEvents/>
        </>
    )
}
export default ExhibitionSocial;