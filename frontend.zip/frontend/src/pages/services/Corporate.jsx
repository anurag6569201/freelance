import CorporateEvents from "./components/corp_serv";

function ServicesCorporate(){
    return (
        <>
            <CorporateEvents/>
        </>
    )
}
export default ServicesCorporate;