import SocialEvents from "./components/social_serv";

function ServicesSocial(){
    return (
        <>
            <SocialEvents/>
        </>
    )
}
export default ServicesSocial;