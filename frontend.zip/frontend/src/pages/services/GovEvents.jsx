import GovEventsEvents from "./components/gov_event_serv";
function GovEventsSocial(){
    return (
        <>
            <GovEventsEvents/>
        </>
    )
}
export default GovEventsSocial;