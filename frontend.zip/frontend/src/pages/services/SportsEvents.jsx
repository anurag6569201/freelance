import SportsEventsEvents from "./components/sports_event_serv";
function SportsEventsSocial(){
    return (
        <>
            <SportsEventsEvents/>
        </>
    )
}
export default SportsEventsSocial;