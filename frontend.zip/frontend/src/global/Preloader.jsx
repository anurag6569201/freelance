function Preloader(){
    return(
        <>
            <div id="preloader"></div>
        </>
    )
}

export default Preloader;