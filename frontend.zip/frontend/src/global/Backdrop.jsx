function Backdrop() {
    return (
        <>
            <div id="thetop" class="thetop"></div>
            <div class='backtotop'>
                <a href="#thetop" class='scroll'>
                    <i class="fas fa-angle-double-up"></i>
                </a>
            </div>
        </>
    )
}

export default Backdrop;